package com.example.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.model.Admin;
import com.example.model.SystemLog;
import com.example.repository.AdminRepository;
import com.example.repository.AppointmentRepository;
import com.example.repository.DoctorRepository;
import com.example.repository.PatientRepository;
import com.example.repository.SystemLogRepository;

import jakarta.transaction.Transactional;

@Service
public class AdminService {

    
    private static final String ROLE_PATIENT = "PATIENT";
    private static final String ROLE_DOCTOR = "DOCTOR";
    private static final String ROLE_ADMIN = "ADMIN";
    private static final String ROLE_SUPER_ADMIN = "SUPER_ADMIN";
    private static final String ACTION_DELETE_USER = "DELETE_USER";
    
    private final AdminRepository adminRepository;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;
    private final SystemLogRepository systemLogRepository;
    private final AppointmentRepository appointmentRepository;


    public AdminService(AdminRepository adminRepository, PatientRepository patientRepository,
			DoctorRepository doctorRepository, SystemLogRepository systemLogRepository,
			AppointmentRepository appointmentRepository) {
		this.adminRepository = adminRepository;
		this.patientRepository = patientRepository;
		this.doctorRepository = doctorRepository;
		this.systemLogRepository = systemLogRepository;
		this.appointmentRepository = appointmentRepository;
	}

	public Admin addAdmin(Admin admin) {
        Admin newAdmin = adminRepository.save(admin);
        systemLogRepository.save(new SystemLog(0, LocalDateTime.now(), newAdmin.getEmail(), "ADD_ADMIN", "New admin created"));
        return newAdmin;
    }

    public List<Object> manageUsers() {
        List<Object> allUsers = new ArrayList<>();
        allUsers.addAll(patientRepository.findAll());
        allUsers.addAll(doctorRepository.findAll());
        allUsers.addAll(adminRepository.findAll());
        return allUsers;
    }

    @Transactional
    public void deleteUser(String role, int id) {
        switch (role.toUpperCase()) {
            case ROLE_PATIENT:
                patientRepository.findById(id).ifPresent(p -> {
                	appointmentRepository.deleteByPatient_PatientId(p.getPatientId());
                    patientRepository.delete(p);
                    systemLogRepository.save(new SystemLog(0, LocalDateTime.now(), p.getEmail(), ACTION_DELETE_USER, "Patient account deleted by Admin"));
                });
                break;
            case ROLE_DOCTOR:
                doctorRepository.findById(id).ifPresent(d -> {
                	appointmentRepository.deleteByDoctor_DoctorId(d.getDoctorId());
                    doctorRepository.delete(d);
                    systemLogRepository.save(new SystemLog(0, LocalDateTime.now(), d.getEmail(), ACTION_DELETE_USER, "Doctor account deleted by Admin"));
                });
                break;
            case ROLE_ADMIN,ROLE_SUPER_ADMIN:      
                adminRepository.findById(id).ifPresent(a -> {
                    adminRepository.delete(a);
                    systemLogRepository.save(new SystemLog(0, LocalDateTime.now(), a.getEmail(), ACTION_DELETE_USER, "Admin account deleted by Admin"));
                });
                break;
            default:
                throw new IllegalArgumentException("Invalid role specified for deletion: " + role);
        }
    }

    public Optional<Admin> findByEmail(String email) {
        return adminRepository.findByEmail(email);
    }
    
    public Optional<Object> getUserByIdAndRole(String role, int id) {
        return switch (role.toUpperCase()) {
            case ROLE_PATIENT -> patientRepository.findById(id).map(p -> (Object) p);
            case ROLE_DOCTOR -> doctorRepository.findById(id).map(d -> (Object) d);
            case ROLE_ADMIN, ROLE_SUPER_ADMIN -> adminRepository.findById(id).map(a -> (Object) a);
            default -> Optional.empty();
        };
    }
}