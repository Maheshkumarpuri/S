package com.example.service;

import java.time.LocalDate;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Date;

import org.springframework.stereotype.Service;

import com.example.model.Appointment;
import com.example.model.SystemLog;
import com.example.repository.AppointmentRepository;
import com.example.repository.DoctorRepository;
import com.example.repository.PatientRepository;
import com.example.repository.SystemLogRepository;

@Service
public class AppointmentService {
     private final AppointmentRepository appointmentRepository;
     private final PatientRepository patientRepository;
     private final DoctorRepository doctorRepository;
     private final SystemLogRepository systemLogRepository;

    public AppointmentService(AppointmentRepository appointmentRepository, PatientRepository patientRepository,
            DoctorRepository doctorRepository, SystemLogRepository systemLogRepository) {
        this.appointmentRepository = appointmentRepository;
        this.patientRepository = patientRepository;
        this.doctorRepository = doctorRepository;
        this.systemLogRepository = systemLogRepository;
    }

    public Appointment bookAppointment(int patientId, int doctorId, Appointment appointment) {
        appointment.setPatient(patientRepository.findById(patientId).orElseThrow(() -> new RuntimeException("Patient not found")));
        appointment.setDoctor(doctorRepository.findById(doctorId).orElseThrow(() -> new RuntimeException("Doctor not found")));
        Date apptDate = appointment.getAppointmentDate(); 
        LocalTime apptTime = appointment.getTimeSlot();   
        if (apptDate == null || apptTime == null) {
            throw new RuntimeException("Appointment date and time slot must be provided");
        }

        LocalDate localDate = apptDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDateTime apptDateTime = LocalDateTime.of(localDate, apptTime);
        if (apptDateTime.isBefore(LocalDateTime.now()) || apptDateTime.isEqual(LocalDateTime.now())) {
            throw new RuntimeException("Cannot book a past time slot.");
        }

        appointment.setStatus(Appointment.AppointmentStatus.BOOKED);
        Appointment newAppointment = appointmentRepository.save(appointment);
        systemLogRepository.save(new SystemLog(0, LocalDateTime.now(), newAppointment.getPatient().getEmail(), "BOOK_APPOINTMENT", "Appointment booked with Doctor " + newAppointment.getDoctor().getName()));
        return newAppointment;
    }

    public Appointment cancelAppointment(int appointmentId) { 
        Appointment appointment = appointmentRepository.findById(appointmentId).orElseThrow(() -> new RuntimeException("Appointment not found"));
        appointment.setStatus(Appointment.AppointmentStatus.CANCELED);
        Appointment canceledAppointment = appointmentRepository.save(appointment); 
        systemLogRepository.save(new SystemLog(0, LocalDateTime.now(), canceledAppointment.getPatient().getEmail(), "CANCEL_APPOINTMENT", "Appointment canceled with Doctor " + canceledAppointment.getDoctor().getName()));
        return canceledAppointment; 
    }

    public List<Appointment> viewAppointmentHistory(int patientId) {
        return appointmentRepository.findByPatient_PatientId(patientId);
    }

    public List<Appointment> viewDoctorSchedule(int doctorId) {
        return appointmentRepository.findByDoctor_DoctorId(doctorId);
    }

    public List<Appointment> getAppointmentsForTomorrowReminder() {
        LocalDate tomorrow = LocalDate.now().plus(1, ChronoUnit.DAYS);
        return appointmentRepository.findAll().stream()
                .filter(appt -> appt.getStatus() == Appointment.AppointmentStatus.BOOKED &&
                                appt.getAppointmentDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate().isEqual(tomorrow))
                .toList();
    }

    public Appointment markAppointmentAsCompleted(int appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
            .orElseThrow(() -> new RuntimeException("Appointment not found"));
        appointment.setStatus(Appointment.AppointmentStatus.COMPLETED);
        Appointment completedAppointment = appointmentRepository.save(appointment);

        systemLogRepository.save(new SystemLog(0, LocalDateTime.now(), 
            completedAppointment.getDoctor().getEmail(), 
            "APPOINTMENT_COMPLETED", 
            "Appointment for patient " + completedAppointment.getPatient().getName() + " marked as completed by Doctor " + completedAppointment.getDoctor().getName()));

        return completedAppointment;
    }
}
