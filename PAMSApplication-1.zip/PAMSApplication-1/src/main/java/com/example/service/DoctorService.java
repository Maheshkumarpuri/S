package com.example.service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.example.model.Appointment;
import com.example.model.Doctor;
import com.example.model.SystemLog;
import com.example.repository.AppointmentRepository;
import com.example.repository.DoctorRepository;
import com.example.repository.SystemLogRepository;

@Service
public class DoctorService {
	private static final Logger logger = LoggerFactory.getLogger(DoctorService.class);

	private final DoctorRepository doctorRepository;
	private final AppointmentRepository appointmentRepository;
	private final SystemLogRepository systemLogRepository;

	public DoctorService(DoctorRepository doctorRepository, AppointmentRepository appointmentRepository,
			SystemLogRepository systemLogRepository) {
		this.doctorRepository = doctorRepository;
		this.appointmentRepository = appointmentRepository;
		this.systemLogRepository = systemLogRepository;
	}

	public Doctor addDoctor(Doctor doctor) {
		if (doctorRepository.existsByEmail(doctor.getEmail())) {
			throw new RuntimeException("Email already exists. Please use another email.");
		}
		Doctor newDoctor = doctorRepository.save(doctor);
		systemLogRepository.save(new SystemLog(0, LocalDateTime.now(), newDoctor.getEmail(), "REGISTER_DOCTOR",
				"New doctor registered"));
		return newDoctor;
	}

	public List<Doctor> getAllDoctors() {
		return doctorRepository.findAll();
	}

	public Doctor updateDoctorAvailability(int doctorId, String availability) {
		Doctor doctor = doctorRepository.findById(doctorId).orElseThrow(() -> new RuntimeException("Doctor not found"));
		doctor.setAvailability(availability);
		systemLogRepository.save(new SystemLog(0, LocalDateTime.now(), doctor.getEmail(), "UPDATE_DOCTOR_AVAILABILITY",
				"Doctor availability updated"));
		return doctorRepository.save(doctor);
	}

	public Optional<Doctor> findByEmail(String email) {
		return doctorRepository.findByEmail(email);
	}

	public Optional<Doctor> findById(int id) {
		return doctorRepository.findById(id);
	}

	public List<String> getAvailableTimeSlots(int doctorId, Date date) {
		Doctor doctor = doctorRepository.findById(doctorId).orElseThrow(() -> new RuntimeException("Doctor not found"));
		List<String> slots = new ArrayList<>();
		String availability = doctor.getAvailability();

		if (availability == null || availability.isEmpty()) {
			return slots;
		}

		if (availability.startsWith("\"") && availability.endsWith("\"") && availability.length() > 1) {
			availability = availability.substring(1, availability.length() - 1);
		}

		try {
			String[] parts = availability.split("-");
			if (parts.length != 2) {
				logger.error("Invalid availability format for doctor {}: {}", doctorId, availability);
				return slots;
			}

			LocalTime startTime = LocalTime.parse(parts[0].trim());
			LocalTime endTime = LocalTime.parse(parts[1].trim());
			LocalTime lastAllowedTime = endTime.minusMinutes(30);

			List<Appointment> doctorAppointments = appointmentRepository.findByDoctor_DoctorId(doctorId);

			LocalTime currentSlot = startTime;
			while (!currentSlot.isAfter(lastAllowedTime)) {
				final LocalTime slotToCheck = currentSlot;

				boolean isBooked = doctorAppointments.stream()
						.anyMatch(appt -> appt.getStatus() == Appointment.AppointmentStatus.BOOKED
								&& appt.getAppointmentDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
										.isEqual(date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate())
								&& appt.getTimeSlot().equals(slotToCheck));

				if (!isBooked) {
					slots.add(currentSlot.toString());
				}
				currentSlot = currentSlot.plusMinutes(30);
			}
		} catch (Exception e) {
			logger.error("Error parsing doctor availability or generating slots for doctor {} with availability '{}'",
					doctorId, availability, e);
		}
		return slots;
	}
}