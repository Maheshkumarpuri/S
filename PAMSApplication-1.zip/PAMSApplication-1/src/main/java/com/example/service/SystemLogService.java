package com.example.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.model.SystemLog;
import com.example.repository.SystemLogRepository;

@Service
public class SystemLogService {
    private final SystemLogRepository systemLogRepository;

    public SystemLogService(SystemLogRepository systemLogRepository) {
		this.systemLogRepository = systemLogRepository;
	}

	public List<SystemLog> viewSystemLogs() { 
        return systemLogRepository.findAllByOrderByTimestampDesc(); 
    }
}

