package com.example.service;

import java.time.LocalDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.example.model.Appointment;
import com.example.model.Notification;
import com.example.repository.NotificationRepository;

@Service
public class NotificationService {
	private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);

	private final NotificationRepository notificationRepository;
	private final JavaMailSender mailSender;
	private final AppointmentService appointmentService;

	public NotificationService(NotificationRepository notificationRepository, JavaMailSender mailSender,
			AppointmentService appointmentService) {
		this.notificationRepository = notificationRepository;
		this.mailSender = mailSender;
		this.appointmentService = appointmentService;
	}

	public List<Notification> getAllNotifications() {
		return notificationRepository.findAllByOrderBySentDateDesc();
	}

	public void sendNotification(int recipientId, String recipientEmail, String message,
			Notification.NotificationType type) {

		Notification notification = new Notification();
		notification.setRecipientId(recipientId);
		notification.setMessage(message);
		notification.setNotificationType(type); 
		notification.setSentDate(LocalDateTime.now());
		notificationRepository.save(notification);

		sendEmail(recipientEmail, "PAMS Appointment Notification", message);
	}

	private void sendEmail(String to, String subject, String body) {
		try {
			SimpleMailMessage mailMessage = new SimpleMailMessage();
			mailMessage.setTo(to);
			mailMessage.setSubject(subject);
			mailMessage.setText(body);
			mailMessage.setFrom("pams.notification@gmail.com");

			mailSender.send(mailMessage);
			logger.info("Email sent successfully to {}", to);
		} catch (MailException e) {
			logger.error("Failed to send email to {}: {}", to, e.getMessage());
		}
	}

	@Scheduled(cron = "0 0 0 * * ?")
	public void sendDailyAppointmentReminders() {
		logger.info("Running scheduled task to send daily appointment reminders...");

		List<Appointment> upcomingAppointments = appointmentService.getAppointmentsForTomorrowReminder();

		if (upcomingAppointments.isEmpty()) {
			logger.info("No appointments found for tomorrow's reminder.");
			return;
		}

		for (Appointment appt : upcomingAppointments) {
			String message = String.format(
					"Reminder: Your appointment with Dr. %s is tomorrow, %s at %s. Please be on time.",
					appt.getDoctor().getName(), appt.getAppointmentDate(), appt.getTimeSlot());
			sendNotification(appt.getPatient().getPatientId(), appt.getPatient().getEmail(), message,
					Notification.NotificationType.REMINDER);
			logger.info("Sent reminder for appointment ID {} to patient {}", appt.getAppointmentId(),
					appt.getPatient().getEmail());
		}
		logger.info("Finished sending daily appointment reminders. Total reminders sent: {}",
				upcomingAppointments.size());
	}
}