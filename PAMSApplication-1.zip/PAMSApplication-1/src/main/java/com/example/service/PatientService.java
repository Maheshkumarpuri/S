package com.example.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.model.Patient;
import com.example.model.SystemLog;
import com.example.repository.PatientRepository;
import com.example.repository.SystemLogRepository;

@Service
public class PatientService {
    
    private final PatientRepository patientRepository;
    private final SystemLogRepository systemLogRepository;

    public PatientService(PatientRepository patientRepository, SystemLogRepository systemLogRepository) {
		this.patientRepository = patientRepository;
		this.systemLogRepository = systemLogRepository;
	}

	public Patient registerPatient(Patient patient) {
		if (patientRepository.existsByEmail(patient.getEmail())) {
	        throw new RuntimeException("Email already exists. Please use another email.");
	    }
        Patient newPatient = patientRepository.save(patient);
        systemLogRepository.save(new SystemLog(0, LocalDateTime.now(), patient.getEmail(), "REGISTER_PATIENT", "New patient registered"));
        return newPatient;
    }
    
    public Optional<Patient> findByEmail(String email) {
        return patientRepository.findByEmail(email);
    }

    public Patient updatePatientProfile(int patientId, Patient patientDetails) {
        Patient patient = patientRepository.findById(patientId).orElseThrow(() -> new RuntimeException("Patient not found"));
        patient.setName(patientDetails.getName());
        patient.setPhone(patientDetails.getPhone());
        patient.setAddress(patientDetails.getAddress());
        patient.setDob(patientDetails.getDob());
        systemLogRepository.save(new SystemLog(0, LocalDateTime.now(), patient.getEmail(), "UPDATE_PATIENT_PROFILE", "Patient profile updated"));
        return patientRepository.save(patient);
    }
    
    public Optional<Patient> findById(int id) {
        return patientRepository.findById(id);
    }
}
