package com.example.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class SystemLog {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "timestamp", nullable = false)
	private LocalDateTime timestamp;

	@Column(name = "user_email", nullable = false, length = 50)
	private String user; 

	@Column(name = "action", nullable = false, length = 100)
	private String action;

	@Column(name = "details", columnDefinition = "TEXT")
	private String details;

	public SystemLog() {
	}

	public SystemLog(int id, LocalDateTime timestamp, String user, String action, String details) {
		this.id = id;
		this.timestamp = timestamp;
		this.user = user;
		this.action = action;
		this.details = details;
	}

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}
}
