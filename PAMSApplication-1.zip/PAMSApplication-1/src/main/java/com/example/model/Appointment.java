package com.example.model;

import jakarta.persistence.*;
import java.util.Date;
import java.time.LocalTime;


@Entity
@Table(name = "Appointment")
public class Appointment {
	public enum AppointmentStatus {
		BOOKED, CANCELED, COMPLETED
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int appointmentId;

	@ManyToOne
	@JoinColumn(name = "patientId", nullable = false)
	private Patient patient;

	@ManyToOne
	@JoinColumn(name = "doctorId", nullable = false)
	private Doctor doctor;

	@Column(name = "appointmentDate", nullable = false)
	private Date appointmentDate;

	@Column(name = "timeSlot", nullable = false)
	private LocalTime timeSlot;

	@Enumerated(EnumType.STRING)
	@Column(name = "status", nullable = false, length = 15)
	private AppointmentStatus status;

	public int getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public LocalTime getTimeSlot() {
		return timeSlot;
	}

	public void setTimeSlot(LocalTime timeSlot) {
		this.timeSlot = timeSlot;
	}

	public AppointmentStatus getStatus() {
		return status;
	}

	public void setStatus(AppointmentStatus status) {
		this.status = status;
	}

	
}
