package com.example.model;

import jakarta.persistence.*;


@Entity
@Table(name = "Doctor")
public class Doctor {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int doctorId;

	@Column(name = "name", nullable = false, length = 50)
	private String name;

	@Column(name = "specialization", nullable = false, length = 50)
	private String specialization;

	@Column(name = "email", nullable = false, unique = true, length = 50)
	private String email;

	@Column(name = "phone", length = 10)
	private String phone;

	@Column(name = "password", nullable = false,length = 10)
	private String password; 

	@Column(name = "availability", columnDefinition = "TEXT")
	private String availability;

	
	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}
}