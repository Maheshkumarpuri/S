package com.example.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "Notification")
public class Notification {
	public enum NotificationType {
		CONFIRMATION, REMINDER
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int notificationId;

	@Column(name = "recipientId", nullable = false)
	private int recipientId;

	@Column(name = "message", columnDefinition = "TEXT", nullable = false)
	private String message;

	@Enumerated(EnumType.STRING)
	@Column(name = "notificationType", nullable = false, length = 15)
	private NotificationType notificationType;

	@Column(name = "sentDate", nullable = false)
	private LocalDateTime sentDate;

	
	public int getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(int notificationId) {
		this.notificationId = notificationId;
	}

	public int getRecipientId() {
		return recipientId;
	}

	public void setRecipientId(int recipientId) {
		this.recipientId = recipientId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public NotificationType getNotificationType() {
		return notificationType;
	}

	public void setNotificationType(NotificationType notificationType) {
		this.notificationType = notificationType;
	}

	public LocalDateTime getSentDate() {
		return sentDate;
	}

	public void setSentDate(LocalDateTime sentDate) {
		this.sentDate = sentDate;
	}
}