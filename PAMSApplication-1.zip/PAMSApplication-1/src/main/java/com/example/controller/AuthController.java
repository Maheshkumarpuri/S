package com.example.controller;

import java.util.Map;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.LoginRequest;
import com.example.dto.LoginResponse;
import com.example.dto.UserDto;
import com.example.model.Admin;
import com.example.model.Doctor;
import com.example.model.Patient;
import com.example.service.AdminService;
import com.example.service.DoctorService;
import com.example.service.PatientService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
	
    private final PatientService patientService;
    private final DoctorService doctorService;
    private final AdminService adminService;

    
    public AuthController(PatientService patientService, DoctorService doctorService, AdminService adminService) {
		this.patientService = patientService;
		this.doctorService = doctorService;
		this.adminService = adminService;
	}


	@PostMapping(value = "/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest request) { 
        UserDto userDto = null;
        String storedPassword = null;
        String role = request.getRole().toUpperCase();
        
        Optional<?> userOpt = Optional.empty();

        if ("PATIENT".equals(role)) {
            userOpt = patientService.findByEmail(request.getEmail());
        } else if ("DOCTOR".equals(role)) {
            userOpt = doctorService.findByEmail(request.getEmail());
        } else if ("ADMIN".equals(role) || "SUPER_ADMIN".equals(role)) {
            userOpt = adminService.findByEmail(request.getEmail());
        }
        
        if (userOpt.isEmpty()) {
             
             return new ResponseEntity<>(Map.of("error", "User not found for the specified role."), HttpStatus.UNAUTHORIZED);
        }
        

        Object user = userOpt.get();
        if (user instanceof Patient patient) {
            storedPassword = patient.getPassword();
            userDto = new UserDto(patient.getPatientId(), patient.getName(), patient.getEmail(), "PATIENT");
        } else if (user instanceof Doctor doctor) {
            storedPassword = doctor.getPassword();
            userDto = new UserDto(doctor.getDoctorId(), doctor.getName(), doctor.getEmail(), "DOCTOR");
        } else if (user instanceof Admin admin) {
            storedPassword = admin.getPassword();
            userDto = new UserDto(admin.getAdminId(), admin.getName(), admin.getEmail(), admin.getRole());
        }

        
        if (request.getPassword().equals(storedPassword)) {
            return ResponseEntity.ok(new LoginResponse(userDto));
        }

        
        return new ResponseEntity<>(Map.of("error", "Invalid password."), HttpStatus.UNAUTHORIZED);
    }
}