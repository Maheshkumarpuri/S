package com.example.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Appointment;
import com.example.model.Notification.NotificationType;
import com.example.service.AppointmentService;
import com.example.service.NotificationService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/appointments")
public class AppointmentController {
    
    private final AppointmentService appointmentService;
    
    private final NotificationService notificationService; 

    
    public AppointmentController(AppointmentService appointmentService, NotificationService notificationService) {
		this.appointmentService = appointmentService;
		this.notificationService = notificationService;
	}


	@PostMapping
    public ResponseEntity<Appointment> bookAppointment(@Valid @RequestBody Appointment appointment) {
        Appointment newAppointment = appointmentService.bookAppointment(appointment.getPatient().getPatientId(), appointment.getDoctor().getDoctorId(), appointment);
        
        
        notificationService.sendNotification(
            newAppointment.getPatient().getPatientId(),
            newAppointment.getPatient().getEmail(),
            "Your appointment with " + newAppointment.getDoctor().getName() + " is confirmed for " + newAppointment.getAppointmentDate() + " at " + newAppointment.getTimeSlot() + ".",
            NotificationType.CONFIRMATION
        );

        return new ResponseEntity<>(newAppointment, HttpStatus.CREATED);
    }


    @DeleteMapping("/{appointmentId}")
    public ResponseEntity<Void> cancelAppointment(@PathVariable int appointmentId) {
        Appointment appointment = appointmentService.cancelAppointment(appointmentId); 
        
        
        notificationService.sendNotification(
            appointment.getPatient().getPatientId(),
            appointment.getPatient().getEmail(),
            "Your appointment with " + appointment.getDoctor().getName() + " on " + appointment.getAppointmentDate() + " has been canceled.",
            NotificationType.CONFIRMATION
        );

        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    @PutMapping(value = "/{appointmentId}/complete")
    public ResponseEntity<Appointment> markAppointmentAsCompleted(@PathVariable int appointmentId) {
        Appointment completedAppointment = appointmentService.markAppointmentAsCompleted(appointmentId);
        return ResponseEntity.ok(completedAppointment);
    }
}
