package com.example.controller;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.RegistrationRequest;
import com.example.model.Appointment;
import com.example.model.Doctor;
import com.example.service.AppointmentService;
import com.example.service.DoctorService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/doctors")
public class DoctorController {
  
    private final DoctorService doctorService;
    private final AppointmentService appointmentService; 
    
    
    public DoctorController(DoctorService doctorService, AppointmentService appointmentService) {
		this.doctorService = doctorService;
		this.appointmentService = appointmentService;
	}


	@GetMapping
    public ResponseEntity<List<Doctor>> getAllDoctors() {
        List<Doctor> doctors = doctorService.getAllDoctors();
        return ResponseEntity.ok(doctors);
    }
    
   
    @PostMapping(value = "/add") 
    public ResponseEntity<?> addDoctor(@Valid @RequestBody RegistrationRequest registrationRequest) {
       try {
    	   Doctor doctor = new Doctor();
           doctor.setName(registrationRequest.getName());
           doctor.setEmail(registrationRequest.getEmail());
           doctor.setPhone(registrationRequest.getPhone());
           doctor.setPassword(registrationRequest.getPassword()); 
           doctor.setSpecialization(registrationRequest.getSpecialization());

           Doctor newDoctor = doctorService.addDoctor(doctor);
           return new ResponseEntity<>(newDoctor, HttpStatus.CREATED);
       }catch (RuntimeException ex) {
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
	    }
       
    }

    
    @PutMapping(value = "/{doctorId}/availability") 
    public ResponseEntity<Doctor> updateDoctorAvailability(@PathVariable int doctorId, @RequestBody String availability) {
        Doctor updatedDoctor = doctorService.updateDoctorAvailability(doctorId, availability);
        return ResponseEntity.ok(updatedDoctor);
    }
    
    @GetMapping("/{doctorId}/availability")
    public ResponseEntity<String> getDoctorAvailability(@PathVariable int doctorId) {
    	Doctor doctor = doctorService.findById(doctorId)
                .orElseThrow(() -> new RuntimeException("Doctor not found"));

        String availability = doctor.getAvailability();
        if (availability == null || availability.trim().isEmpty()) {
            return ResponseEntity.ok("NO_AVAILABILITY");
        }
        return ResponseEntity.ok(availability);
    }


 
    @GetMapping(value = "/{doctorId}/schedule") 
    public ResponseEntity<List<Appointment>> viewDoctorSchedule(@PathVariable int doctorId) {
        List<Appointment> schedule = appointmentService.viewDoctorSchedule(doctorId); 
        return ResponseEntity.ok(schedule);
    }


    @GetMapping(value = "/{doctorId}/time-slots") 
    public ResponseEntity<List<String>> getAvailableTimeSlots(@PathVariable int doctorId,
                                                              @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date date) {
        List<String> timeSlots = doctorService.getAvailableTimeSlots(doctorId, date);
        return ResponseEntity.ok(timeSlots);
    }
}