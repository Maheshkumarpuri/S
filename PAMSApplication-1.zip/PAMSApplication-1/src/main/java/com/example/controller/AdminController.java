package com.example.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Admin;
import com.example.model.Doctor;
import com.example.model.Notification;
import com.example.model.Patient;
import com.example.model.SystemLog;
import com.example.service.AdminService;
import com.example.service.NotificationService;
import com.example.service.SystemLogService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

   
    private final AdminService adminService;
    private final SystemLogService systemLogService;
    private final NotificationService notificationService;


    public AdminController(AdminService adminService, SystemLogService systemLogService, NotificationService notificationService) {
        this.adminService = adminService;
        this.systemLogService = systemLogService;
        this.notificationService = notificationService;
    }

    @PostMapping(value = "/users")
    public ResponseEntity<Admin> addAdmin(@Valid @RequestBody Admin admin) {
        Admin newAdmin = adminService.addAdmin(admin);
        return new ResponseEntity<>(newAdmin, HttpStatus.CREATED);
    }
    
    @GetMapping(value = "/users")
    public ResponseEntity<List<Object>> manageUsers() {
        List<Object> users = adminService.manageUsers();
        return ResponseEntity.ok(users);
    }
    
    @GetMapping(value = "/users/{role}/{id}")
    public ResponseEntity<Object> getUserProfile(@PathVariable String role, @PathVariable int id) {
        Optional<Object> userOpt = adminService.getUserByIdAndRole(role, id);
        
        if (userOpt.isPresent()) {
            Object user = userOpt.get();
            if ("PATIENT".equalsIgnoreCase(role) && user instanceof Patient patient) {
                return ResponseEntity.ok(patient);
            } else if ("DOCTOR".equalsIgnoreCase(role) && user instanceof Doctor doctor) {
                return ResponseEntity.ok(doctor);
            } else if (("ADMIN".equalsIgnoreCase(role) || "SUPER_ADMIN".equalsIgnoreCase(role)) && user instanceof Admin admin) {
                return ResponseEntity.ok(admin);
            }
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    
    @DeleteMapping("/users/{role}/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable String role, @PathVariable int id) {
        adminService.deleteUser(role, id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    @GetMapping(value = "/system-logs")
    public ResponseEntity<List<SystemLog>> viewSystemLogs() {
        List<SystemLog> logs = systemLogService.viewSystemLogs();
        return ResponseEntity.ok(logs);
    }

    @GetMapping(value = "/notifications")
    public ResponseEntity<List<Notification>> viewNotifications() {
        List<Notification> notifications = notificationService.getAllNotifications();
        return ResponseEntity.ok(notifications);
    }
}