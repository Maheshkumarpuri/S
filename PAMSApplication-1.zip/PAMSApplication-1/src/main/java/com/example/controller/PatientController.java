package com.example.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dto.RegistrationRequest;
import com.example.model.Appointment;
import com.example.model.Patient;
import com.example.service.AppointmentService;
import com.example.service.PatientService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/patients")
public class PatientController {
	private final PatientService patientService;
	private final AppointmentService appointmentService;

	public PatientController(PatientService patientService, AppointmentService appointmentService) {
		this.patientService = patientService;
		this.appointmentService = appointmentService;
	}

	@PostMapping
	public ResponseEntity<?> registerPatient(@Valid @RequestBody RegistrationRequest registrationRequest) {
	    try {
	        Patient patient = new Patient();
	        patient.setName(registrationRequest.getName());
	        patient.setEmail(registrationRequest.getEmail());
	        patient.setPhone(registrationRequest.getPhone());
	        patient.setAddress(registrationRequest.getAddress());
	        patient.setDob(registrationRequest.getDob());
	        patient.setPassword(registrationRequest.getPassword());

	        Patient newPatient = patientService.registerPatient(patient);
	        return new ResponseEntity<>(newPatient, HttpStatus.CREATED);

	    } catch (RuntimeException ex) {
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
	    }
	}


	@PutMapping(value = "/{patientId}")
	public ResponseEntity<Patient> updatePatientProfile(@PathVariable int patientId,
			@Valid @RequestBody Patient patientDetails) {
		Patient updatedPatient = patientService.updatePatientProfile(patientId, patientDetails);
		return ResponseEntity.ok(updatedPatient);
	}

	@GetMapping(value = "/{patientId}")
	public ResponseEntity<Patient> getPatientProfile(@PathVariable int patientId) {
		return patientService.findById(patientId).map(ResponseEntity::ok)
				.orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	}

	@GetMapping(value = "/{patientId}/appointments/history")
	public ResponseEntity<List<Appointment>> viewAppointmentHistory(@PathVariable int patientId) {
		List<Appointment> appointments = appointmentService.viewAppointmentHistory(patientId);
		return ResponseEntity.ok(appointments);
	}
}