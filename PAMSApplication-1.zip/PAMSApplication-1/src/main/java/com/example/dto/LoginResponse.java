package com.example.dto;


public class LoginResponse {

	private UserDto user;

	public LoginResponse(UserDto user) {
		this.user = user;
	}

	public UserDto getUser() {
		return user;
	}

}
