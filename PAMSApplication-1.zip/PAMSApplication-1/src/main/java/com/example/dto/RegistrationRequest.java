package com.example.dto;

import jakarta.validation.constraints.*;
import java.util.Date;

public class RegistrationRequest {
	@NotBlank(message = "Name is required.")
	private String name;

	@NotBlank(message = "Email is required.")
	@Email(message = "Email should be a valid email address.")
	private String email;

	@NotBlank(message = "Phone number is required.")
	@Pattern(regexp = "^[6-9]\\d{9}$", message = "Phone number must start with 6-9 and be exactly 10 digits.")
	private String phone;

	@NotBlank(message = "Address is required.")
	private String address;

	@NotNull(message = "Date of birth is required.")
	@Past(message = "Date of birth must be in the past.")
	private Date dob;

	@NotBlank(message = "Password is required.")
	@Pattern(regexp = "^(?=.{8,}$)(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[^A-Za-z0-9])(?!.*\\s).*$", message = "Password must be at least 8 characters, include uppercase, lowercase, digit and special character, and contain no spaces.")
	private String password;

	private String specialization;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
}
