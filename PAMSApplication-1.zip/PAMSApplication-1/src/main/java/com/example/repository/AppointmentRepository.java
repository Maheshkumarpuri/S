package com.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.Appointment;

public interface AppointmentRepository extends JpaRepository<Appointment, Integer> { 
    List<Appointment> findByPatient_PatientId(int patientId);
    List<Appointment> findByDoctor_DoctorId(int doctorId);
    
    void deleteByDoctor_DoctorId(int doctorId);
    void deleteByPatient_PatientId(int patientId);

}