package com.example.repository;

import com.example.model.SystemLog;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SystemLogRepository extends JpaRepository<SystemLog, Integer> { 
    List<SystemLog> findAllByOrderByTimestampDesc();
}

