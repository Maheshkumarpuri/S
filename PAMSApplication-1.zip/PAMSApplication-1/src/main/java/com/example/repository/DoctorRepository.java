package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.Doctor;

import java.util.Optional;

public interface DoctorRepository extends JpaRepository<Doctor, Integer> { 
    Optional<Doctor> findByEmail(String email);
    boolean existsByEmail(String email);
}
