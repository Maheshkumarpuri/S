const baseURL = "http://localhost:8080/api";

function showMessage(message, type = 'info', duration = 5000, scope) {
  let $container;

  const useModal = scope === 'modal';

  if (useModal && $('.modal.show').length) {
    const $modal = $('.modal.show');
    if ($modal.find('.messageBoxContainer').length === 0) {
      $modal.find('.modal-body').prepend('<div class="messageBoxContainer mb-2"></div>');
    }
    $container = $modal.find('.messageBoxContainer');
  } else {
    if ($('#messageBoxContainer').length === 0) {
      $('body').append('<div id="messageBoxContainer" class="position-fixed top-0 end-0 p-3" style="z-index:2000;"></div>');
    }
    $container = $('#messageBoxContainer');
  }

  const $alertDiv = $(`
    <div class="alert alert-${type} alert-dismissible fade show message-box" role="alert">
      ${message}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  `);
  $container.append($alertDiv);

  if (duration > 0) {
    setTimeout(() => $alertDiv.alert('close'), duration);
  }
}

function showModalMessage(message, type = 'warning', duration = 5000) {
  showMessage(message, type, duration, 'modal');
}

async function api(endpoint = "", method = "GET", data = null) {
  const options = {
    method,
    headers: {
      "Content-Type": "application/json",
      "Accept": "application/json" 
    }
  };
  if (data != null) options.body = JSON.stringify(data);
  const res = await fetch(baseURL + endpoint, options);
  if (!res.ok) {
    let errorMessage = await res.text();
    try {
      const errorJson = JSON.parse(errorMessage);
      if (errorJson.message) {
        errorMessage = errorJson.message;
      } else if (errorJson.errors && errorJson.errors.length > 0) {
        errorMessage = errorJson.errors.map(err => err.defaultMessage || err.message).join(", ");
      } else if (errorJson.error) {
        errorMessage = errorJson.error + (errorJson.message ? ": " + errorJson.message : "");
      }
    } catch (e) {
      
    }
    throw new Error(errorMessage);
  }
  if (res.status === 204) return null;
  return res.json();
}

function pad2(n){ return (n<10 ? '0' + n : '' + n); }

function formatDateOnly(dateStrOrVal) {
  if (!dateStrOrVal) return '';
  const d = (typeof dateStrOrVal === 'string' || typeof dateStrOrVal === 'number') ? new Date(dateStrOrVal) : dateStrOrVal;
  if (isNaN(d.getTime())) return dateStrOrVal;
  return `${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())}`;
}

function normalizeTime(slot) {

  if (!slot && slot !== 0) return '';
  const s = String(slot);
  const parts = s.split(':');
  if (parts.length >= 2) return `${pad2(parseInt(parts[0],10))}:${pad2(parseInt(parts[1],10))}`;
 
  const d = new Date(s);
  if (!isNaN(d.getTime())) return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
  return s;
}

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())}`;
}

function nowTimeHHMM() {
  const d = new Date();
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

function isPastDate(isoDate) {
  if (!isoDate) return false;
  return isoDate < todayISO();
}

function isPastDateTime(isoDate, timeSlot) {
  if (!isoDate) return false;
  const t = normalizeTime(timeSlot);
  const today = todayISO();
  if (isoDate < today) return true;
  if (isoDate > today) return false;
  
  return t < nowTimeHHMM();
}

function isNameValid(name) {
  return /^[A-Za-z]+(?:\s[A-Za-z]+)*$/.test(name.trim());
}

function isDobValid(dob) {
  if (!dob) return false;
  const selected = new Date(dob);
  const today = new Date();
  return selected <= today;
}

function isPhoneValid(phone) {
  if (!phone) return false;
  const trimmed = phone.trim();
  return /^0?[6-9][0-9]{9}$/.test(trimmed);
}

function isEmailValid(email) {
  return /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email.trim());
}
function isPasswordValid(password) {
  const passwordPattern = /^(?=.{8,}$)(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[^A-Za-z0-9])(?!.*\s).*$/;
  return passwordPattern.test(password);
}


function normalizePhone(phone) {
  return phone.trim().replace(/^0/, '');
}

function dateOnlyPart(s) {
  if (!s) return '';
  return String(s).replace(/[T ].*$/, '');
}

function toLocalDateTime(dateLike, timeLike) {
  const d = dateOnlyPart(dateLike);
  const t = normalizeTime(timeLike);               
  const hhmmss = t && t.length === 5 ? `${t}:00` : t; 
  return new Date(`${d}T${hhmmss}`);    
}


async function loginUser(e) {
  e.preventDefault();
  const $form = $(e.target);
  const form = $form[0];
  if (!form.checkValidity()) {
    $form.addClass('was-validated');
    return;
  }
  const payload = {
    email: $form.find('[name="email"]').val(),
    password: $form.find('[name="password"]').val(),
    role: $form.find('[name="role"]').val()
  };
  try {
    const result = await api("/auth/login", "POST", payload);
    sessionStorage.setItem("user", JSON.stringify(result.user));
    switch (result.user.role) {
      case "PATIENT": window.location = "patient_dashboard.html"; break;
      case "DOCTOR": window.location = "doctor_dashboard.html"; break;
      case "ADMIN":
      case "SUPER_ADMIN": window.location = "admin_dashboard.html"; break;
      default: window.location = "login.html";
    }
  } catch (err) {
    showMessage("Login failed: " + err.message, 'danger');
  }
}

async function registerPatient(e) {
  e.preventDefault();
  const $form = $(e.target);
  const form = $form[0];
  if (!form.checkValidity()) {
    $form.addClass('was-validated');
    return;
  }

  const nameVal = $form.find('[name="name"]').val();
  const phoneVal = $form.find('[name="phone"]').val();
  const dobVal = $form.find('[name="dob"]').val();
  const emailVal = $form.find('[name="email"]').val();
  const passwordVal = $form.find('[name="password"]').val();

  if (!isNameValid(nameVal)) {
    showMessage("Name must contain only letters and spaces, 2–50 characters long.", 'danger');
    return;
  }

  if (!isEmailValid(emailVal)) {
    showMessage("Please enter a valid email address (e.g., user@example.com).", 'danger');
    return;
  }

  if (!isPhoneValid(phoneVal)) {
    showMessage("Phone must start with 6-9 (or 0 + 6-9), be 10 digits long.", 'danger');
    return;
  }

  if (!isDobValid(dobVal)) {
    showMessage("Invalid DOB. Future dates are not allowed.", 'danger');
    return;
  }

  if (!isPasswordValid(passwordVal)) {
    showMessage("Password must be at least 8 characters, include uppercase, lowercase, digit and special character, and contain no spaces.", 'danger');
    return;
  }

  const payload = {
    name: nameVal.trim(),
    email: $form.find('[name="email"]').val(),
    phone: normalizePhone(phoneVal),
    address: $form.find('[name="address"]').val(),
    dob: dobVal,
    password: $form.find('[name="password"]').val(),
  };
  const role = $form.find('[name="role"]').val();
  let registerEndpoint;
  if (role === "PATIENT") {
    registerEndpoint = "/patients";
  } else if (role === "DOCTOR") {
    registerEndpoint = "/doctors/add";
    payload.specialization = $form.find('[name="specialization"]').val();
    if (!payload.specialization && form.querySelector('#specializationInput')) {
      form.querySelector('#specializationInput').setCustomValidity('Specialization is required for doctors.');
      form.reportValidity();
      return;
    } else if (form.querySelector('#specializationInput')) {
      form.querySelector('#specializationInput').setCustomValidity('');
    }
  } else {
    showMessage("Invalid role selected.", 'danger');
    return;
  }

  try {
    await api(registerEndpoint, "POST", payload);
    showMessage("Registration successful! Please login.", 'success');
    window.location = "login.html";
  } catch (err) {
    showMessage("Error: " + err.message, 'danger');
  }
}

function logout() {
  sessionStorage.removeItem("user");
  window.location = "login.html";
}

async function loadPatientAppointments() {
  const user = JSON.parse(sessionStorage.getItem("user") || "{}");
  if (!user.id || user.role !== 'PATIENT') {
    showMessage("Unauthorized access or user ID missing. Redirecting to login.", 'danger');
    setTimeout(() => window.location = "login.html", 2000);
    return;
  }

  const $tbody = $("#appointmentTable tbody");
  if ($tbody.length === 0) return;
  $tbody.empty();

  try {
    const appointments = await api(`/patients/${user.id}/appointments/history`);
    $.each(appointments, function(index, appt) {
      const dPart = dateOnlyPart(appt.appointmentDate);
      const dateOnly = dPart; 
      const timeOnly = normalizeTime(appt.timeSlot);
      const apptDateTime = toLocalDateTime(dPart, appt.timeSlot);

      let cancelBtn = "";
      if (appt.status === "BOOKED") {
        const now = new Date();
        const minutesUntilAppt = (apptDateTime - now) / 60000;
        if (!isNaN(minutesUntilAppt) && minutesUntilAppt <= 30) {
          cancelBtn = `<button class="btn btn-sm btn-secondary" disabled>Cancel</button>`;
        } else {
          cancelBtn = `<button class="btn btn-sm btn-danger cancel-appt-btn" data-id="${appt.appointmentId}" data-bs-toggle="modal" data-bs-target="#confirmationModal">Cancel</button>`;
        }
      }
      const $tr = $(`
        <tr>
          <td>${dateOnly}</td>
          <td>${timeOnly}</td>
          <td>${appt.doctor.name}</td>
          <td>${appt.status}</td>
          <td>${cancelBtn}</td>
        </tr>
      `);
      $tbody.append($tr);
    });
  } catch (err) {
    console.error(err);
    showMessage("Failed to load patient appointments: " + err.message, 'danger');
  }
}

async function populateDoctorSelect() {
  const $select = $("#doctorSelect");
  if ($select.length === 0) return;
  try {
    const doctors = await api("/doctors");
    $select.empty();
    $select.append('<option value="" disabled selected>Select a Doctor</option>');
    $.each(doctors, function(index, d) {
      $select.append(`<option value="${d.doctorId}">${d.name} — ${d.specialization}</option>`);
    });
    $('#doctorSelect').trigger('change');
  } catch (err) {
    console.error(err);
    showMessage("Failed to load doctors: " + err.message, 'danger');
  }
}

async function loadAvailableTimeSlots() {
  const doctorId = $('#doctorSelect').val();
  const appointmentDate = $('#appointmentDateInput').val(); 
  const $timeSlotSelect = $('#timeSlotSelect');
  const $bookBtn = $('#bookAppointmentBtn');
  $timeSlotSelect.empty().append('<option value="" disabled selected>Select a Time Slot</option>');

  if (!doctorId || !appointmentDate) {
    if ($bookBtn.length) $bookBtn.prop('disabled', true);
    return;
  }

  if (isPastDate(appointmentDate)) {
    showModalMessage("You have selected a past date. Please choose today or a future date.", 'warning');
    if ($bookBtn.length) $bookBtn.prop('disabled', true);
    $timeSlotSelect.append('<option value="" disabled>Cannot select slots for past dates</option>');
    return;
  }

  try {
    const rawSlots = await api(`/doctors/${doctorId}/time-slots?date=${appointmentDate}`);
    let timeSlots = (rawSlots || []).map(s => normalizeTime(s));

    const today = todayISO();
    if (appointmentDate === today) {
      const now = new Date();
      timeSlots = timeSlots.filter(slot => {
        const slotDateTime = toLocalDateTime(appointmentDate, slot);
        return (slotDateTime - now) / 60000 >= 30;
      });
    }

    if (!timeSlots || timeSlots.length === 0) {
      $timeSlotSelect.append('<option value="" disabled>No future slots available for this date.</option>');
      if ($bookBtn.length) $bookBtn.prop('disabled', true);
      showModalMessage("No future slots available for this date. Please choose another date or doctor.", 'warning');
      return;
    }

    timeSlots.forEach(slot => {
      $timeSlotSelect.append(`<option value="${slot}">${slot}</option>`);
    });
    
    if ($bookBtn.length) $bookBtn.prop('disabled', true);

  } catch (err) {
    console.error("Error loading time slots:", err);
    showMessage("Failed to load time slots: " + err.message, 'danger');
    if ($bookBtn.length) $bookBtn.prop('disabled', true);
  }
}

async function bookAppointment(e) {
  e.preventDefault();
  const $form = $(e.target);
  const form = $form[0];
  const $bookBtn = $('#bookAppointmentBtn');

  if (!form.checkValidity()) {
    $form.addClass('was-validated');
    return;
  }

  const user = JSON.parse(sessionStorage.getItem("user") || "{}");
  if (!user.id) {
    showMessage("User not logged in. Please login again.", 'danger');
    return;
  }

  const appointmentDate = $form.find('[name="appointmentDate"]').val();
  const timeSlot = $form.find('[name="timeSlot"]').val();
  const doctorId = $form.find('[name="doctorId"]').val();

  if (!appointmentDate || !timeSlot || !doctorId) {
    showMessage("Please choose doctor, date and a valid time slot.", 'warning');
    return;
  }

  if (isPastDateTime(appointmentDate, timeSlot)) {
    showModalMessage("Selected time is in the past. Choose another slot.", 'warning');
    return;
  }

  const payload = {
    patient: { patientId: user.id },
    doctor: { doctorId: doctorId },
    appointmentDate: appointmentDate,
    timeSlot: timeSlot
  };

  try {
    $bookBtn.prop('disabled', true);
    await api("/appointments", "POST", payload);

    const modalEl = document.getElementById('bookModal');
    $(modalEl).one('hidden.bs.modal', function () {
      showMessage("Appointment booked!", 'success');
      loadPatientAppointments();
    });

    const bookModal = bootstrap.Modal.getInstance(modalEl);
    if (bookModal) {
      if (document.activeElement && document.activeElement.blur) document.activeElement.blur();

      bookModal.hide();
    }

    $form.removeClass('was-validated')[0].reset();

  } catch (err) {
    showMessage("Error booking appointment: " + err.message, 'danger');
  } finally {
    setTimeout(() => {
      $('#doctorSelect, #appointmentDateInput').trigger('change');
    }, 400);
  }
}

async function loadDoctorSchedule() {
  const user = JSON.parse(sessionStorage.getItem("user") || "{}");
  if (!user.id || user.role !== 'DOCTOR') {
    showMessage("Unauthorized access or user ID missing. Redirecting to login.", 'danger');
    setTimeout(() => window.location = "login.html", 2000);
    return;
  }

  const $tbody = $("#scheduleTable tbody");
  if ($tbody.length === 0) return;
  $tbody.empty();

  try {
    const schedule = await api(`/doctors/${user.id}/schedule`);
    $.each(schedule, function(index, item) {
      const dPart = dateOnlyPart(item.appointmentDate);
      const timeOnly = normalizeTime(item.timeSlot);
      const apptDateTime = toLocalDateTime(dPart, item.timeSlot);
      const now = new Date();
      const canComplete = (item.status === "BOOKED") && !isNaN(apptDateTime) && now >= apptDateTime;
      const $tr = $(`
        <tr>
          <td>${dPart}</td>
          <td>${timeOnly}</td>
          <td>${item.patient?.name || ''}</td>
          <td>${item.status}</td>
          <td>
            ${canComplete
              ? `<button class="btn btn-sm btn-success mark-complete-btn" data-id="${item.appointmentId}">Mark as Completed</button>`
              : (item.status === "BOOKED" ? `<span class="text-muted">Upcoming</span>` : "")
            }
          </td>
        </tr>
      `);
      $tbody.append($tr);
    });
  } catch (err) {
    console.error(err);
    showMessage("Failed to load doctor schedule: " + err.message, 'danger');
  }
}

async function loadDoctorAvailability() {
  const user = JSON.parse(sessionStorage.getItem("user") || "{}");
  if (!user.id || user.role !== 'DOCTOR') return;

  try {
    const availability = await api(`/doctors/${user.id}/availability`);
    
    if (availability === "NO_AVAILABILITY") {
      $("#currentAvailability").text("No availability set yet. Please update your availability.");
    } else {
      $("#currentAvailability").text(`Current Availability: ${availability}`);
    }

  } catch (err) {
    console.error(err);
    $("#currentAvailability").text("Error fetching availability");
  }
}

async function updateAvailability(e) {
  e.preventDefault();
  const $form = $(e.target);
  const form = $form[0];
  if (!form.checkValidity()) {
    $form.addClass('was-validated');
    return;
  }

  const user = JSON.parse(sessionStorage.getItem("user") || "{}");
  if (!user.id) {
    showMessage("User not logged in or ID missing. Please log in again.", 'danger');
    return;
  }
  const startTime = $form.find('[name="startTime"]').val();
  const endTime = $form.find('[name="endTime"]').val();
  const payload = `${startTime}-${endTime}`;
  try {
    await api(`/doctors/${user.id}/availability`, "PUT", payload);
    showMessage("Availability updated!", 'success');
    const availabilityModal = bootstrap.Modal.getInstance(document.getElementById('availabilityModal'));
    if (availabilityModal) availabilityModal.hide();
    $form.removeClass('was-validated')[0].reset();
    loadDoctorSchedule();
  } catch (err) {
    showMessage("Error updating availability: " + err.message, 'danger');
  }
}

async function markAppointmentCompleted(appointmentId) {
  try {
    await api(`/appointments/${appointmentId}/complete`, "PUT");
    showMessage("Appointment marked as completed!", 'success');
    loadDoctorSchedule();
  } catch (err) {
    showMessage("Error marking appointment as completed: " + err.message, 'danger');
  }
}


async function manageUsers() {
  const user = JSON.parse(sessionStorage.getItem("user") || "{}");
  if (!user.id || (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) {
    showMessage("Unauthorized access to user management. Redirecting to login.", 'danger');
    setTimeout(() => window.location = "login.html", 2000);
    return;
  }
  const $tbody = $("#usersTable tbody");
  if ($tbody.length === 0) return;
  $tbody.empty();
  try {
    const users = await api("/admin/users");
    $.each(users, function(index, u) {
      const id = u.patientId || u.doctorId || u.adminId;
      const role = (u.role || (u.patientId ? 'PATIENT' : 'DOCTOR')).toUpperCase().trim();
      const name = u.name;
      const email = u.email;
      const $tr = $(`
        <tr data-id="${id}" data-role="${role}">
          <td>${id}</td>
          <td>${name}</td>
          <td>${email}</td>
          <td>${role}</td>
          <td>
            <a href="user_profile.html?id=${id}&role=${role}" class="btn btn-sm btn-info">View</a>
            ${role !== 'SUPER_ADMIN'
              ? `<button class="btn btn-sm btn-danger delete-user-btn"
                        data-id="${id}"
                        data-role="${role}"
                        data-bs-toggle="modal"
                        data-bs-target="#confirmationModal">Delete</button>`
              : ''
            }
          </td>
        </tr>
      `);
      $tbody.append($tr);
    });
  } catch (err) {
    console.error(err);
    showMessage("Failed to load users: " + err.message, 'danger');
  }
}

async function addAdmin(e) {
  e.preventDefault();
  const $form = $(e.target);
  const form = $form[0];

  const emailVal = $form.find('[name="email"]').val();
  if (!isEmailValid(emailVal)) {
    showMessage("Please enter a valid email address (e.g., admin@example.com).", 'danger');
    return;
  }

  if (!form.checkValidity()) {
    $form.addClass('was-validated');
    return;
  }

  const payload = {
    name: $form.find('[name="name"]').val(),
    email: $form.find('[name="email"]').val(),
    role: $form.find('[name="role"]').val(),
    password: $form.find('[name="password"]').val()
  };
  try {
    await api("/admin/users", "POST", payload);
    showMessage("Admin created!", 'success');
    $form.removeClass('was-validated')[0].reset();
    manageUsers();
    setTimeout(() => {
      window.location = "admin_dashboard.html";
    }, 1000);
    
  } catch (err) {
    let errorMessage = "Error: " + err.message;
    showMessage(errorMessage, 'danger');
  }
}

async function viewSystemLogs() {
  const user = JSON.parse(sessionStorage.getItem("user") || "{}");
  if (!user.id || (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) {
    showMessage("Unauthorized access to system logs. Redirecting to login.", 'danger');
    setTimeout(() => window.location = "login.html", 2000);
    return;
  }
  const $tbody = $("#logsTable tbody");
  if ($tbody.length === 0) return;
  $tbody.empty();
  try {
    const logs = await api("/admin/system-logs");
    $.each(logs, function(index, log) {
      const $tr = $(`<tr><td>${log.timestamp}</td><td>${log.user}</td><td>${log.action}</td><td>${log.details}</td></tr>`);
      $tbody.append($tr);
    });
  } catch (err) {
    showMessage("Failed to load logs: " + err.message, 'danger');
  }
}

async function viewNotifications() {
  const user = JSON.parse(sessionStorage.getItem("user") || "{}");
  if (!user.id || (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) {
    showMessage("Unauthorized access to notifications. Redirecting to login.", 'danger');
    setTimeout(() => window.location = "login.html", 2000);
    return;
  }
  const $list = $("#notificationList");
  if ($list.length === 0) return;
  $list.empty();
  try {
    const notifs = await api("/admin/notifications");
    $.each(notifs, function(index, n) {
      const $li = $(`<li class="list-group-item">${n.sentDate} — ${n.message}</li>`);
      $list.append($li);
    });
  } catch (err) {
    console.error(err);
    showMessage("Failed to load notifications: " + err.message, 'danger');
  }
}

async function loadPatientProfile() {
  const user = JSON.parse(sessionStorage.getItem("user") || "{}");
  if (!user.id || user.role !== 'PATIENT') {
    showMessage("Unauthorized access or user ID missing. Redirecting to login.", 'danger');
    setTimeout(() => window.location = "login.html", 2000);
    return;
  }
  try {
    const patientDetails = await api(`/patients/${user.id}`);
    $("#profileNameInput").val(patientDetails.name);
    $("#profileEmailInput").val(patientDetails.email);
    $("#profilePhoneInput").val(patientDetails.phone);
    $("#profileAddressTextarea").val(patientDetails.address);
    $("#profileDobInput").val(formatDateOnly(patientDetails.dob));
  } catch (err) {
    showMessage("Failed to load profile details: " + err.message, 'danger');
  }
}

async function updatePatientProfile(e) {
  e.preventDefault();
  const $form = $(e.target);
  const form = $form[0];
  if (!form.checkValidity()) {
    $form.addClass('was-validated');
    return;
  }

  const nameVal = $form.find('[name="name"]').val();
  const phoneVal = $form.find('[name="phone"]').val();
  const dobVal = $form.find('[name="dob"]').val();
  const emailVal = $form.find('[name="email"]').val();
  
  if (!isNameValid(nameVal)) {
    showMessage("Name must contain only letters and spaces, 2–50 characters long.", 'danger');
    return;
  }

  if (!isEmailValid(emailVal)) {
    showMessage("Please enter a valid email address (e.g., admin@example.com).", 'danger');
    return;
  }

  if (!isPhoneValid(phoneVal)) {
    showMessage("Phone must start with 6-9 (or 0 + 6-9), be 10 digits long.", 'danger');
    return;
  }

  if (!isDobValid(dobVal)) {
    showMessage("Invalid DOB. Future dates are not allowed.", 'danger');
    return;
  }

  const payload = {
    name: nameVal.trim(),
    email: $form.find('[name="email"]').val(),
    phone: normalizePhone(phoneVal),
    address: $form.find('[name="address"]').val(),
    dob: dobVal
  };

  const user = JSON.parse(sessionStorage.getItem("user") || "{}");
  if (!user.id) {
    showMessage("User not found. Please log in again.", 'danger');
    return;
  }

  try {
    await api(`/patients/${user.id}`, "PUT", payload);
    showMessage("Profile updated successfully!", 'success');
    setTimeout(() => {
      window.location = "patient_dashboard.html";
    }, 1000);
    
  } catch (err) {
    showMessage("Error updating profile: " + err.message, 'danger');
  }
}

async function loadUserProfile() {
  const urlParams = new URLSearchParams(window.location.search);
  const userId = urlParams.get('id');
  const userRole = urlParams.get('role');

  if (!userId || !userRole) {
    showMessage("User ID or Role not found in URL. Redirecting to admin dashboard.", 'danger');
    setTimeout(() => window.location = "admin_dashboard.html", 2000);
    return;
  }

  const currentUser = JSON.parse(sessionStorage.getItem("user") || "{}");
  if (!currentUser.id || (currentUser.role !== 'ADMIN' && currentUser.role !== 'SUPER_ADMIN')) {
    showMessage("Unauthorized access to user profile. Redirecting to login.", 'danger');
    setTimeout(() => window.location = "login.html", 2000);
    return;
  }

  try {
    const user = await api(`/admin/users/${userRole}/${userId}`);
    $("#profileUserId").val(userId);
    $("#profileUserName").val(user.name);
    $("#profileUserEmail").val(user.email);
    $("#profileUserRole").val(userRole);
    $("#doctorSpecializationGroup").hide();
    $("#patientInfoGroup").hide();

    if (userRole === 'DOCTOR') {
      $("#doctorSpecializationGroup").show();
      $("#profileUserSpecialization").val(user.specialization);
    } else if (userRole === 'PATIENT') {
      $("#patientInfoGroup").show();
      $("#profileUserPhone").val(user.phone);
      $("#profileUserAddress").val(user.address);
      $("#profileUserDob").val(formatDateOnly(user.dob));
    }

    $("#userProfileForm input, #userProfileForm textarea, #userProfileForm select").attr("disabled", true);

    if ($("#backToAdminBtn").length === 0) {
      $("#userProfileForm").append(`
        <button id="backToAdminBtn" type="button" class="btn btn-secondary mt-3">
          <i class="bi bi-arrow-left"></i> Back
        </button>
      `);
      $("#backToAdminBtn").on("click", function () {
        window.location = "admin_dashboard.html";
      });
    }

  } catch (err) {
    showMessage("Failed to load user details: " + err.message, 'danger');
  }
}


let appointmentToCancel = null;
let userToDelete = null;
$(document).ready(function() {
  $('#loginForm').on("submit", loginUser);
  $('#registerForm').on("submit", registerPatient);
  $('#logoutBtn').on("click", logout);
  $('#roleSelect').on('change', function() {
    if ($(this).val() === 'DOCTOR') {
      $('#specializationGroup').show();
      $('#specializationInput').attr('required', 'required');
    } else {
      $('#specializationGroup').hide();
      $('#specializationInput').removeAttr('required');
    }
  }).trigger('change');

  const $bookForm = $("#bookForm");
  if ($bookForm.length > 0) {
    populateDoctorSelect();
    $bookForm.on("submit", bookAppointment);
    loadPatientAppointments();
    $('#doctorSelect, #appointmentDateInput').on('change', function() {
      loadAvailableTimeSlots();
      $('#timeSlotSelect').val('');
      $('#bookAppointmentBtn').prop('disabled', true);
    });
    $('#timeSlotSelect').on('change', function() {
      const chosen = $(this).val();
      if (chosen && !isPastDateTime($('#appointmentDateInput').val(), chosen)) {
        $('#bookAppointmentBtn').prop('disabled', false);
      } else {
        $('#bookAppointmentBtn').prop('disabled', true);
        if (chosen) showModalMessage("Selected time is in the past. Choose another slot.", 'warning');
      }
    });
  }

  $('#bookModal').on('show.bs.modal', function() {
    $(this).find('.messageBoxContainer').remove();
    $('#bookAppointmentBtn').prop('disabled', true);
    $('#timeSlotSelect').val('');
  });

  $('#appointmentTable tbody').on('click', '.cancel-appt-btn', function() {
    appointmentToCancel = $(this).data('id');
  });

  $('#confirmCancelBtn').on('click', async function () {
    if (appointmentToCancel) {
      const modalEl = document.getElementById('confirmationModal');
      try {
        await api(`/appointments/${appointmentToCancel}`, "DELETE");
  
        $(modalEl).one('hidden.bs.modal', function () {
          showMessage("Appointment canceled successfully!", 'success');
          loadPatientAppointments();
        });
  
        bootstrap.Modal.getInstance(modalEl)?.hide();
  
      } catch (err) {
        $(modalEl).one('hidden.bs.modal', function () {
          showMessage("Error canceling appointment: " + err.message, 'danger');
        });
        bootstrap.Modal.getInstance(modalEl)?.hide();
      } finally {
        appointmentToCancel = null;
      }
    }
  });
  
  if ($("#patientProfileForm").length > 0) {
    loadPatientProfile();
    $("#patientProfileForm").on("submit", updatePatientProfile);
  }

  const $availabilityForm = $("#availabilityForm");
  if ($availabilityForm.length > 0) {
    $availabilityForm.on("submit", updateAvailability);
    loadDoctorAvailability();
    loadDoctorSchedule();
    setInterval(loadDoctorAvailability, 2000);
  }
  $('#scheduleTable').on('click', '.mark-complete-btn', function() {
    const apptId = $(this).data('id');
    if (apptId) markAppointmentCompleted(apptId);
  });

  const $addAdminForm = $("#addAdminForm");
  if ($addAdminForm.length > 0) {
    $addAdminForm.on("submit", addAdmin);
  }

  $(document).on('click', '.password-toggle', function () {
    const $input = $(this).siblings('input');
    const $icon = $(this).find('i');

    if ($input.attr('type') === 'password') {
      $input.attr('type', 'text');
      $icon.removeClass('bi-eye-slash').addClass('bi-eye');
    } else {
      $input.attr('type', 'password');
      $icon.removeClass('bi-eye').addClass('bi-eye-slash');
    }
  });

  $(document).on('input', 'input[type="password"], input[type="text"][name="password"]', function () {
  const $toggle = $(this).siblings('.password-toggle');
  if ($(this).val().length > 0) {
    $toggle.removeClass('d-none');
  } else {
    $toggle.addClass('d-none');
  }
});

  if ($("#usersTable").length > 0) manageUsers();
  if ($("#logsTable").length > 0) viewSystemLogs();
  if ($("#notificationList").length > 0) viewNotifications();
  if ($("#userProfileForm").length > 0) loadUserProfile();

  $('#usersTable tbody').on('click', '.delete-user-btn', function() {
    userToDelete = { id: $(this).data('id'), role: $(this).data('role') };
  });
  $('#confirmDeleteBtn').on('click', async function() {
    if (userToDelete) {
      try {
        await api(`/admin/users/${userToDelete.role}/${userToDelete.id}`, "DELETE");
        showMessage("User deleted successfully!", 'success');
        $('#confirmationModal').modal('hide');
        manageUsers();
      } catch (err) {
        showMessage("Error deleting user: " + err.message, 'danger');
      } finally {
        userToDelete = null;
      }
    }
  });
});