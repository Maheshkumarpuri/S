package com.tfms;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TFMSApplication {

	public static void main(String[] args) {
		SpringApplication.run(TFMSApplication.class, args);
	}

}
